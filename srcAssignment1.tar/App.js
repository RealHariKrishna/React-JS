import History from './Component/History/index'

import './App.css'

// These are the list used in the application. You can move them to any component needed.

// Replace your code here
const App = () => <History />

export default App
