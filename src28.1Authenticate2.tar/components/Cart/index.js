// Write your JS code here
import Header from '../Header'

import './index.css'

const Cart = () => (
  <>
    <Header />
    <div className="container">
      <img
        src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-img.png"
        alt="cart"
        className="img"
      />
    </div>
  </>
)

export default Cart
