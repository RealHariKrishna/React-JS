import Stopwatch from './components/Stopwatch'

import './App.css'

const App = () => <Stopwatch />

export default App
