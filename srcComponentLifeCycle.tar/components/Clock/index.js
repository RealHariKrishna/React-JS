import {Component} from 'react'
import './index.css'

class Clock extends Component {
  constructor(props) {
    super(props)
    this.state = {date: Date.now()}
    console.log('Constructor ')
  }

  componentDidMount() {
    console.log('componentDidMount ')
    this.timerId = setInterval(this.tick, 1000)
  }

  componentWillUnmount() {
    console.log('unMount')
    clearInterval(this.timerId)
  }

  tick = () => {
    this.setState({date: new Date()})
  }

  render() {
    const {date} = this.state
    console.log('render', date)
    return (
      <div className="clock-container">
        <h1 className="heading">Clock</h1>
        <p className="time">{new Date(date).toLocaleTimeString()}</p>
      </div>
    )
  }
}
export default Clock
