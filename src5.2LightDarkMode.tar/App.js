import LightDarkMode from './components/LightDarkMode'

import './App.css'

const App = () => <LightDarkMode />

export default App
