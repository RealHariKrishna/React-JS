import {Route, Switch} from 'react-router-dom'

import CourseHome from './components/CourseHome'

import CourseDetails from './components/CourseDetails'

import NotFoundPage from './components/NotFoundPage'

import './App.css'

const App = () => (
  <Switch>
    <Route exact path="/" component={CourseHome} />
    <Route exact path="/courses/:id" component={CourseDetails} />
    <Route component={NotFoundPage} />
  </Switch>
)

export default App
