import RandomNumberGenerator from './components/RandomNumberGenerator'

import './App.css'

const App = () => <RandomNumberGenerator />

export default App
