import TextInput from './components/TextInput'

import './App.css'

// Replace your code here
const App = () => <TextInput />

export default App
