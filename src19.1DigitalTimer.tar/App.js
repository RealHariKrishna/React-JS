import DigitalTimer from './components/DigitalTimer'

import './App.css'

const App = () => <DigitalTimer />

export default App
