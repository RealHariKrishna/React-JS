import TextEditor from './components/TextEditor'
import './App.css'

// Replace your code here
const App = () => <TextEditor />

export default App
