import './index.css'

const Footer = () => (
  <div className="f-container">
    <h1 className="f-text">Footer</h1>
  </div>
)

export default Footer
