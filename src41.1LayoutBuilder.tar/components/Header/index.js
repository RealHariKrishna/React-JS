import './index.css'

const Header = () => (
  <div className="h-container">
    <h1 className="h-text">Header</h1>
  </div>
)

export default Header
