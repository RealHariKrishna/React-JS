import LettersCalculator from './components/LettersCalculator'

import './App.css'

const App = () => <LettersCalculator />

export default App
