import './index.css'

const Pages = props => {
  const {pageDetails, clickPageItem, isActive} = props
  const {id, buttonText} = pageDetails

  const onClickPageItem = () => {
    clickPageItem(id)
  }

  const activePageBtnClassName = isActive ? 'active-page-btn' : ''

  return (
    <li className="page-item-container">
      <button
        type="button"
        className={`page-btn ${activePageBtnClassName}`}
        onClick={onClickPageItem}
      >
        {buttonText}
      </button>
    </li>
  )
}

export default Pages
