import Capitals from './components/Capitals'

import './App.css'

const App = () => <Capitals />

export default App
