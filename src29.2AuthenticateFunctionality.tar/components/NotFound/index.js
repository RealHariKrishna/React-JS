// Write your JS code here
import './index.css'

const NotFound = () => (
  <div className="container">
    <h1 className="heading">Not Found</h1>
  </div>
)

export default NotFound
