import TravelGuide from './components/TravelGuide'
import './App.css'

// Replace your code here
const App = () => <TravelGuide />

export default App
