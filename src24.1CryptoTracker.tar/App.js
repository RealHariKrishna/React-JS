import CryptocurrencyTracker from './components/CryptocurrencyTracker'

import './App.css'

const App = () => <CryptocurrencyTracker />

export default App
