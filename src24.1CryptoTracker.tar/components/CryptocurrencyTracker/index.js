// Write your code here
import {Component} from 'react'
import Loader from 'react-loader-spinner'

import CrytocurrenciesList from '../CryptocurrenciesList'

import './index.css'

const apiUrl = 'https://apis.ccbp.in/crypto-currency-converter'

class CrytocurrencyTracker extends Component {
  state = {
    cryptocurrenciesData: [],
    isLoading: true,
  }

  componentDidMount() {
    this.getCrypto()
  }

  getCrypto = async () => {
    const response = await fetch(apiUrl)
    const data = await response.json()

    this.setState({
      cryptocurrenciesData: data.map(eachCrypto => ({
        id: eachCrypto.id,
        currencyLogoUrl: eachCrypto.currency_logo,
        currencyName: eachCrypto.currency_name,
        usdValue: eachCrypto.usd_value,
        euroValue: eachCrypto.euro_value,
      })),
      isLoading: false,
    })
  }

  renderCrypto = () => {
    const {cryptocurrenciesData} = this.state

    return <CrytocurrenciesList cryptocurrenciesData={cryptocurrenciesData} />
  }

  renderLoader = () => (
    <div data-testid="loader">
      <Loader type="Rings" color="#ffffff" height={80} width={80} />
    </div>
  )

  render() {
    const {isLoading} = this.state

    return (
      <div className="app-container">
        {isLoading ? this.renderLoader() : this.renderCrypto()}
      </div>
    )
  }
}

export default CrytocurrencyTracker
