import ShowHide from './components/ShowHide'

import './App.css'

const App = () => <ShowHide />

export default App
