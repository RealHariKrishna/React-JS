// Write your code here
import './index.css'

const NotFound = () => (
  <div className="container">
    <h1 className="heading">Page Not Found !!</h1>
  </div>
)

export default NotFound
