import AlertNotifications from './components/AlertNotifications'

import './App.css'

const App = () => <AlertNotifications />

export default App
