import RegistrationForm from './components/RegistrationForm'
import './App.css'

const App = () => <RegistrationForm />

export default App
